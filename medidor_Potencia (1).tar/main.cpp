/* mbed Microcontroller Library
 * Copyright (c) 2019 ARM Limited
 * SPDX-License-Identifier: Apache-2.0
 */

#include "mbed.h"
#include <cstdint>
#include "math.h"
#include "Adafruit_GFX.h"
#include "Adafruit_SSD1306.h"

class I2CPreInit : public I2C
{
public:
    I2CPreInit(PinName sda, PinName scl) : I2C(sda, scl)
    {
        frequency(400000);
        start();
    };
};

#define WAIT_TIME_MS 500
#define N 100
#define SDA p28
#define SCL p27
AnalogIn curIn(p19);
AnalogIn  vin(p20);
volatile uint16_t carr[N],varr[N];
float cfarr[N],vfarr[N]; //vector de corriente de 100 muestras
volatile uint8_t readyf=0;//bandera para la ISR desde el proceso 
I2CPreInit oledI2C(SDA, SCL);
Adafruit_SSD1306_I2c myOled(oledI2C, p11, 0x78, 64, 128);
Ticker t;

void sample(){
    static uint16_t i=0;
    if(i<100 && readyf==0){
     carr[i]=curIn.read_u16();
     varr[i]=vin.read_u16();
     i++;
     
    }
    else if(readyf==0) {
        i=0;
        readyf=1;

    }
 }
 void show_values(volatile uint16_t* carr, float* cfarr, volatile uint16_t* varr, float* vfarr);
// void filtradoC(volatile uint16_t* carrorig, float* carrfilt);//funcion que regresa los valores de la corriente real
 void filtradoV(volatile uint16_t* varrorig, float* varrfilt);//funcion que regresa los valores reales de voltaje
 void encontrarPicoYValle(float vector[], int longitud, int *indicePico, int *indiceValle);
 void implementDate();

int main()
{
    //uint16_t vread=vin.read_u16();//valores entre 0 y 1.0
    //float vreal=vread*3.3*100/65535.0;//valor real de voltaje haciendo la conversion
    t.attach(sample,167us);
    
    while (true)
    {
        //led1 = !led1;
        //thread_sleep_for(WAIT_TIME_MS);
        if(readyf == 1){
            t.detach();
            filtradoV(carr,cfarr);
            filtradoV(varr,vfarr);
            show_values(varr,vfarr,carr,cfarr);

            implementDate();
            readyf =0;
        
            t.attach(sample,167us);
        }
        
    }
}


void show_values(volatile uint16_t* carr, float* cfarr, volatile uint16_t* varr, float* vfarr){
    for(int i=0;i<N; i++){
        printf("%u,%f,%u,%f \n",carr[i],cfarr[i],varr[i],vfarr[i]);
    }
}

//objeto
void impcadena(const char *str, int x, int y, uint16_t color, uint16_t size) //Funcion para imprimir cadenas de caracteres
{
    myOled.setTextCursor(x, y); //Acomodo la ubicacion del cursor
    myOled.setTextColor(color); //Acomodo el color de la letra
    myOled.setTextSize(size); //Acomoda el tamaño de la letra
    
    while (*str != '\0') //Recorre todos los valores de la cadena hasta que un caracter sea nulo
    {
        myOled.writeChar(*str);
        str++; //Contador de caracteres
    }
    
    myOled.display(); //Actualiza el display
}

void filtradoV(volatile uint16_t* varrorig, float* varrfilt){
        varrfilt[0]=varrorig[0];
        varrfilt[1]=varrorig[1];
        for (int i=2;i<100;i++){
            varrfilt[i]=0.02178*varrorig[i-1]+0.01963*varrorig[i-2]+1.691*varrfilt[i-1]-0.7327*varrfilt[i-2];
            //varrfilt[i]=(varrfilt[i]*3.3/65535)*0.0016;     //voltaje real  
        }
}

void filtradoC(volatile uint16_t* carrorig, float* carrfilt){
        carrfilt[0]=carrorig[0];
        carrfilt[1]=carrorig[1];
        for (int i=2;i<100;i++){
            carrfilt[i]=0.02178*carrorig[i-1]+0.01963*carrorig[i-2]+1.691*carrfilt[i-1]-0.7327*carrfilt[i-2];
            //carrfilt[i]=(carrfilt[i]*3.3/65535)*0.185;//corriente real
        }
}

void parseFloatString(float numero, char* cadena, int longitud) {
    //  snprintf se formatea el número como una cadena
    snprintf(cadena, longitud, "%.2f", numero); // "%.2f" para 2 decimales
}

void encontrarPicoYValle(float vector[], int longitud, int *indicePico, int *indiceValle) {
    // Inicializar el índice del pico y el valle
    *indicePico = 0;
    *indiceValle = 0;

    // Buscar el pico y el valle
    for (int i = 1; i < longitud; i++) {
        // Buscar el pico
        if (vector[i] > vector[*indicePico]) {
            *indicePico = i;
        }
        // Buscar el valle
        if (vector[i] < vector[*indiceValle]) {
            *indiceValle = i;
        }
    }
}

 
void implementDate(){
    int16_t x = 0;
    int16_t y = 0;
    unsigned char c = 'm';
    uint16_t color =  1; //Letra blanca
    uint16_t  size=2;
    uint16_t idx_arr[4];
    char miCadena[20], miCadena2[20], miCadena3[20], miCadena4[20], miCadena5[20], miCadena6[20], miCadena7[20], miCadena8[20];
    char cadenaConcatenada1[30], cadenaConcatenada2[30], cadenaConcatenada3[30], cadenaConcatenada4[30], cadenaConcatenada5[30], cadenaConcatenada6[30], cadenaConcatenada7[30], cadenaConcatenada8[30];
    char resultado1[100], resultado2[100];
    int iDXpik_arrI,iDXvalley_arrI,iDXpik_arrV,iDXvalley_arrV;
    encontrarPicoYValle(cfarr,N, &iDXpik_arrI, &iDXvalley_arrI);
    encontrarPicoYValle(vfarr,N, &iDXpik_arrV, &iDXvalley_arrV);
    //Calculo de variables respectivas
    float i_pk=(cfarr[iDXpik_arrI]-cfarr[iDXvalley_arrI])/2.0, v_pk=(vfarr[iDXvalley_arrI]-vfarr[iDXvalley_arrI])/2.0;
    v_pk=(v_pk*3.3/65535)*0.0016;//conversion a valor real
    i_pk=(i_pk*3.3/65535)*0.185;//conversion a valor real
    float vrms=v_pk/sqrt(2), irms=i_pk/sqrt(2);
    float angulo=((iDXpik_arrI-iDXpik_arrV)*((1.0/60.0)*N)*377.0);
    float s=vrms*irms; //Aparente y promedio
    float fp=cos(angulo), Q=s*sin(angulo), P=s*fp;//factor de potencia, potencia reactiva, potencia real
    printf("i_pk= %f, v_pk= %f  \n", i_pk, v_pk);
    printf("pi_pk= %u, pv_pk= %u \n", idx_arr[0], idx_arr[1]);
    printf("Irms= %f, Vrms= %f \n", irms, vrms);
    printf("Aparente= %f, F.potencia= %f \n", s, fp);
    printf("P.reactiva= %f, P.real= %f \n", Q, P);
    for(int i=0; i<N; i++){
        printf("%f, %f \n", cfarr[i], vfarr[i]);
    }
    thread_sleep_for(1000); //1 segundo de espera
    myOled.clearDisplay();
    myOled.setTextCursor(0,0);
    myOled.begin(); //Inicializa las librerias
    myOled.clearDisplay();//Limpia la pantalla
    parseFloatString(i_pk, miCadena, sizeof(miCadena)); //Llamamos a la funcion para convertir a float
    parseFloatString(v_pk, miCadena2, sizeof(miCadena2));
    parseFloatString(irms, miCadena3, sizeof(miCadena3));
    parseFloatString(vrms, miCadena4, sizeof(miCadena4));
    parseFloatString(s, miCadena5, sizeof(miCadena5));
    parseFloatString(fp, miCadena6, sizeof(miCadena6));
    parseFloatString(Q, miCadena7, sizeof(miCadena7));
    parseFloatString(P, miCadena8, sizeof(miCadena8));
    snprintf(resultado1, sizeof(resultado1), "IpK=%s\nVpK=%s\ncEfic=%s\nVefic=%s", 
             miCadena, miCadena2, miCadena3, miCadena4);
    snprintf(resultado2, sizeof(resultado2), "pAp=%s\nFacP=%s\npRea=%s\nPAct=%s", 
             miCadena5, miCadena6, miCadena7, miCadena8);
    impcadena(resultado1, 0, 0, color, size);
    myOled.clearDisplay();
    thread_sleep_for(1000);
    impcadena(resultado2, 0, 0, color, size);

}


//volatile significa que la variable que sigue va en la ram
//libreria ssd1306 adafrut ssd1306